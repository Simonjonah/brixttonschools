    <footer class="main-footer style-three">
    	<div class="auto-container">
        	<!--Widgets Section-->
            <div class="widgets-section">
            	<div class="row clearfix">
                	
                    <!--Column-->
                    <div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
						
                        	<!--Footer Column-->
                            <div class="footer-column col-lg-7 col-md-6 col-sm-12">
                                <div class="footer-widget logo-widget">
									<div class="logo">
										<a href="home"><img style="height: 70px; width: 200px;" src="<?php echo e(asset('images/sch14.jpg')); ?>" alt="" /></a>
									</div>
									<div class="text">For additioan information on BRIXTONN SCHOOLS services. Please contact us using the information below.</div>
									<ul class="list-style-two">
										<li><span class="icon fa fa-phone"></span> +234 816 7930 965</li>
										<li><span class="icon fa fa-envelope"></span> info@brixtonn.com.ng</li>
										<li><span class="icon fa fa-home"></span>30 G Line, Ewet Housing Estate, Uyo <br> Akwa Ibom, Nigeria</li>
									</ul>
								</div>
							</div>
							
							<!--Footer Column-->
                            <div class="footer-column col-lg-5 col-md-6 col-sm-12">
                                <div class="footer-widget links-widget">
									<h4>Links</h4>
									<ul class="list-link">
										<li><a href="home">Home</a></li>
										<li><a href="services">Services</a></li>
										<li><a href="about">About us</a></li>
										<li><a href="home">Testimonials</a></li>
										<li><a href="blog">Press Release</a></li>
										<li><a href="contact">Contact</a></li>
									</ul>
								</div>
							</div>

						</div>
					</div>
					
					<!--Column-->
                    <div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
						
                        	<!--Footer Column-->
                            <div class="footer-column col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget links-widget">
									<h4>Support</h4>
									<ul class="list-link">
										<li><a href="contact">Contact Us</a></li>
										<li><a href="">Complaint</a></li>
										<li><a href="home">Visit Knowledge Base</a></li>
										<li><a href="contact">Support System</a></li>
										<li><a href="teacheradmin/login">Teacher's login</a></li>
										<li><a href="#">Refund Policy</a></li>
									</ul>
								</div>
							</div>
							
							<!--Footer Column-->
                            <div class="footer-column col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget gallery-widget">
									<h4>Gallery</h4>
									<div class="widget-content">
										<div class="images-outer clearfix">
											<!--Image Box-->
											<figure class="image-box"><a href="<?php echo e(asset('images/gallery/1.jpg')); ?>" class="lightbox-image" data-fancybox="footer-gallery" title="Image Title Here" data-fancybox-group="footer-gallery"><img style="width: 100%; height: 60px;" src="<?php echo e(asset('images/gallery/1.jpg')); ?>" alt=""></a></figure>
											<!--Image Box-->
											<figure class="image-box"><a href="<?php echo e(asset('images/gallery/2.jpg')); ?>" class="lightbox-image" data-fancybox="footer-gallery" title="Image Title Here" data-fancybox-group="footer-gallery"><img style="width: 100%; height: 60px;" src="<?php echo e(asset('images/gallery/2.jpg')); ?>" alt=""></a></figure>
											<!--Image Box-->
											<figure class="image-box"><a href="<?php echo e(asset('images/gallery/4.jpg')); ?>" class="lightbox-image" data-fancybox="footer-gallery" title="Image Title Here" data-fancybox-group="footer-gallery"><img style="width: 100%; height: 60px;" src="<?php echo e(asset('images/gallery/4.jpg')); ?>" alt=""></a></figure>
											<!--Image Box-->
											<figure class="image-box"><a href="<?php echo e(asset('images/gallery/6.jpg')); ?>" class="lightbox-image" data-fancybox="footer-gallery" title="Image Title Here" data-fancybox-group="footer-gallery"><img style="width: 100%; height: 60px;" src="<?php echo e(asset('images/gallery/6.jpg')); ?>" alt=""></a></figure>
											<!--Image Box-->
											<figure class="image-box"><a href="<?php echo e(asset('images/gallery/5.jpg')); ?>" class="lightbox-image" data-fancybox="footer-gallery" title="Image Title Here" data-fancybox-group="footer-gallery"><img style="width: 100%; height: 60px;" src="<?php echo e(asset('images/gallery/5.jpg')); ?>" alt=""></a></figure>
											<!--Image Box-->
											<figure class="image-box"><a href="<?php echo e(asset('images/gallery/7.jpg')); ?>" class="lightbox-image" data-fancybox="footer-gallery" title="Image Title Here" data-fancybox-group="footer-gallery"><img style="width: 100%; height: 60px;" src="<?php echo e(asset('images/gallery/7.jpg')); ?>" alt=""></a></figure>
											<!--Image Box-->
											<figure class="image-box"><a href="<?php echo e(asset('images/gallery/10.jpg')); ?>" class="lightbox-image" data-fancybox="footer-gallery" title="Image Title Here" data-fancybox-group="footer-gallery"><img style="width: 100%; height: 60px;" src="<?php echo e(asset('images/gallery/10.jpg')); ?>" alt=""></a></figure>
											<!--Image Box-->
											<figure class="image-box"><a href="<?php echo e(asset('images/gallery/11.jpg')); ?>" class="lightbox-image" data-fancybox="footer-gallery" title="Image Title Here" data-fancybox-group="footer-gallery"><img style="width: 100%; height: 60px;" src="<?php echo e(asset('images/gallery/11.jpg')); ?>" alt=""></a></figure>
											<!--Image Box-->
											<figure class="image-box"><a href="<?php echo e(asset('images/gallery/12.jpg')); ?>" class="lightbox-image" data-fancybox="footer-gallery" title="Image Title Here" data-fancybox-group="footer-gallery"><img style="width: 100%; height: 60px;" src="<?php echo e(asset('images/gallery/12.jpg')); ?>" alt=""></a></figure>
										</div>
									</div>
								</div>
							</div>
							
						</div>
					</div>
					
				</div>
			</div>
		</div>
		<!-- Footer Bottom -->
		<div class="footer-bottom">
			<div class="auto-container">
				<div class="row clearfix">
					
					<!-- Copyright Column -->
					<div class="copyright-column col-lg-6 col-md-6 col-sm-12">
						<div class="copyright">2021 &copy; All rights reserved by <a href="#">Simon 08167930965</a></div>
					</div>
					
					<!-- Social Column -->
					<div class="social-column col-lg-6 col-md-6 col-sm-12">
						<ul>
							<li class="follow">Follow us: </li>
							<li><a href="#"><span class="fa fa-facebook-square"></span></a></li>
							<li><a href="#"><span class="fa fa-twitter-square"></span></a></li>
							<li><a href="#"><span class="fa fa-linkedin-square"></span></a></li>
							<li><a href="#"><span class="fa fa-google-plus-square"></span></a></li>
							<li><a href="#"><span class="fa fa-rss-square"></span></a></li>
						</ul>
					</div>
					
				</div>
			</div>
		</div>
	</footer>
	
</div>
<!--End pagewrapper-->

<script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.fancybox.js')); ?>"></script>
<script src="<?php echo e(asset('js/appear.js')); ?>"></script>
<script src="<?php echo e(asset('js/owl.js')); ?>"></script>
<script src="<?php echo e(asset('js/mixitup.js')); ?>"></script>
<script src="<?php echo e(asset('js/wow.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>


</body>

<!-- Mirrored from themexriver.com/tfhtml/finano/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 17 Jan 2019 01:59:48 GMT -->
</html><?php /**PATH C:\xampp\htdocs\brixttonschools\resources\views/pages/common/footer.blade.php ENDPATH**/ ?>