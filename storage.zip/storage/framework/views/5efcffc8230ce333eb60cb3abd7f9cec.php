<?php echo $__env->make('pages.common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--End Main Header -->
	
	<!--Page Title-->
    
    <!--End Page Title-->
	
	<!-- Contact Page Section -->
	<section class="contact-page-section">
		<div class="auto-container">
			<div class="inner-container">
				<div class="sec-title centered">
				<div class="title"> Teachers Registration</div>
				<h2>Teachers <span>Registration</span></h2>
				
			</div>
				<div class="row clearfix">
					
					<!-- Info Column -->
					<div class="info-column col-lg-6 col-md-12 col-sm-12">
						<div class="contactform">
							<form method="post" action="<?php echo e(url('createteacher')); ?>" enctype="multipart/form-data">
								<?php echo csrf_field(); ?>
								<?php if(Session::get('success')): ?>
								  <div class="alert alert-success">
									  <?php echo e(Session::get('success')); ?>

								  </div>
								  <?php endif; ?>
		  
								  <?php if(Session::get('fail')): ?>
								  <div class="alert alert-danger">
								  <?php echo e(Session::get('fail')); ?>

								  </div>
							  <?php endif; ?>
								<div class="form-group">
									<h5>First Name</h5>
									<input class="form-control" value="<?php echo e(old('fname')); ?>" <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> type="text" name="fname" value="" placeholder="First Name" required="">
								</div>
								
								<div class="form-group">
									<h5>OtherNames</h5>
									<input type="text" name="othername" value="<?php echo e(old('lname')); ?>" <?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> class="form-control" placeholder="Othernames" required="">
								</div>

								<div class="form-group">
									<h5>Class</h5>
									<select class="form-control" type="text" name="class" value="" placeholder="Class" required="">
										<option>Reception</option>
										<option>Pre-School</option>
										<option>KG 1</option>
										<option>KG 2</option>
										<option>Elementary 1</option>
										<option>Elementary 2</option>
										<option>Elementary 3</option>
										<option>Elementary 4</option>
										<option>Elementary 5</option>
									</select>
									
								</div>
								
								<div class="form-group">
				                  <h5>Select Alms</h5>
				                  <select class="form-control" name="alms" required="">
				                    <option>Smart</option>
				                    <option>Bright</option>
				                    <option>Clever</option>
				                    <option>Awesome</option>
				                    <option>Radiant</option>
				                    <option>Fast</option>
				                    <option>Sharp</option>
				                    <option>Brilliant</option>
				                  </select>
				                </div> 
								<div class="form-group">
									<h5>Gender</h5>
									<select class="form-control" name="gender" required="">
										<option>Male</option>
										<option>Female</option>
									</select>
								</div>
								
								
                               
						</div>
					</div>
					
					<!-- Form Column -->
					<div class="form-column col-lg-6 col-md-12 col-sm-12">
						<div class="innercolumn">
							
							<div class="form-group">
								<h5>Phone</h5>
								<input type="text" name="phone" class="form-control" placeholder="Phone" required="">
							</div>
							<div class="form-group">
								<h5>Email</h5>
								<input type="email" name="email" class="form-control" placeholder="Email" required="">
							</div>
							 
							<div class="form-group">
								<h5>Password</h5>
								<input type="password" name="password" class="form-control" placeholder="Password" required="">
							</div>

							<div class="form-group">
								<h5>Address</h5>
								<input type="text" name="address" class="form-control" placeholder="Address" required="">
							</div>
								
							<div class="form-group">
								<h4>UPLOAD PASSPORD</h4>
                				<input type="file" name="fileToUpload" id="fileToUpload" required="">
							</div>
							<div class="form-group">
								<button type="submit" class="btn btn-success">Submit</button>	
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
	<!-- End Team Page Section -->

	<?php echo $__env->make('pages.common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\brixttonschools\resources\views/pages/teacherform.blade.php ENDPATH**/ ?>