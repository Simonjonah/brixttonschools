
<?php echo $__env->make('pages.common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<!--Page Title-->
    <section class="page-title" style="background-image:url(images/background/bri2.jpg)">
    	<div class="auto-container">
			<div class="content">
				<h1>Team <span>Member</span></h1>
				<ul class="page-breadcrumb">
					<li><a href="home">Home</a></li>
					<li>Pages</li>
					<li>Team</li>
				</ul>
			</div>
        </div>
    </section>
    <!--End Page Title-->

	<!-- Team Page Section -->
	<section class="team-page-section">
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title centered">
				<div class="title">About us</div>
				<h2 style="color: purple;" >We have a large experts <br>team with <span style="color: pink;">experience</span></h2>
			</div>

			<div class="row clearfix">

				<?php $__currentLoopData = $view_teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view_team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="team-block-two style-two col-lg-3 col-md-6 col-sm-12">
					<div class="inner-box wow fadeIn" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="image">
							<a href="#"><img style="width: 100%; height: 300px;" src="<?php echo e(URL::asset("/public/../$view_team->images")); ?>" alt="" title=""></a>
							<ul class="social-box">
								<li><a href="<?php echo e($view_team->facebook); ?>" class="fa fa-facebook"></a></li>
								<li><a href="<?php echo e($view_team->twitter); ?>" class="fa fa-twitter"></a></li>
								<li><a href="<?php echo e($view_team->linkedin); ?>" class="fa fa-linkedin"></a></li>
							</ul>
						</div>
						<div class="lower-content">
							<h5><a href="<?php echo e(url('viewsinglemember/'.$view_team->ref_no)); ?>"><?php echo e($view_team->fname); ?> <?php echo e($view_team->lname); ?></a></h5>
							<div class="designation"><a href="<?php echo e(url('viewsinglemember/'.$view_team->ref_no)); ?>"><?php echo e($view_team->designation); ?></a></div>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</section>
	<!-- End Team Page Section -->

	<?php echo $__env->make('pages.common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\xampp\htdocs\brixttonschools\resources\views/pages/team.blade.php ENDPATH**/ ?>